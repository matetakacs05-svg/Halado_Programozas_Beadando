from pathlib import Path
import cv2
import yt_dlp
from ultralytics import YOLO

YOUTUBE_URL = "https://www.youtube.com/watch?v=zMCea32gpmg"

# 1. YouTube stream címének lekérése
ydl_opts = {
    "format": "bestvideo*",
    "quiet": False,
    "js_runtimes": {
        "bun": {}
    },
    "remote_components": ["ejs:npm"]
}

with yt_dlp.YoutubeDL(ydl_opts) as ydl:
    info = ydl.extract_info(YOUTUBE_URL, download=False)
    stream_url = info["url"]

# 2. AI modell betöltése
model = YOLO("yolo26s.pt")

# 3. Videó megnyitása
cap = cv2.VideoCapture(stream_url)

if not cap.isOpened():
    print("Nem sikerült megnyitni a streamet!")
    exit()

print("A stream elindult.")

# 4. Feldolgozás
while True:
    ret, frame = cap.read()

    if not ret:
        print("Nem érkezik több képkocka.")
        break

    results = model.track(
        frame,
        persist=True,
        tracker=str(Path(__file__).parent / "custom_botsort.yaml"),
        classes=[0, 1],
        conf=0.15,
        iou=0.5,
        imgsz=1536,
        device=0,
        verbose=False
    )

    # Felismert objektumok megjelenítése
    annotated_frame = results[0].plot()

    cv2.imshow("Szia- AI Detection", annotated_frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()